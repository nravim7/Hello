package com.example.Banking.actions;

public class CustomerDetailsResponse {
    private Boolean temp;
    private String message;
    public Boolean getTemp() {
        return temp;
    }

    public void setTemp(Boolean temp) {
        this.temp = temp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


}
