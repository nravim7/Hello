export class UserUpdate {
    
    prevpassword:string;
    password: string;
    
}