export class User {
    firstname: string;
    lastname: string;
    fathername: string;
    gender: string;
    userName:string;
    password: string;
    dob:Date;
    phone: number;
    address:string;
    type:string;
    identityno:number;
    adharno: number;
    email: string;
    }

export class Login {
    username:string;
    password: string;
    
}

