export class UserDisplay{
    accnono:number;
    balance:number;

    // primaryAccno:number;
    // savingsAccno:number;
    // primaryBalance:number;
    // savingsBalance:number;

}