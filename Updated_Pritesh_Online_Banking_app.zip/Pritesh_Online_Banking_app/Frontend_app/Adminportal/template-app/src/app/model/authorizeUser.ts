export class AuthorizeUser{
    firstname:string;
    lastname: string;
    phone: number;
    address: string;
    //pan: string;
    email: string;
    username: string;
}
